
            <!-- Main Container -->
            <main id="main-container" style="background: #ffffff;">
                <!-- Page Header -->
                <div class="content bg-image overflow-hidden" style="background-image: url('<?php echo base_url(); ?>/assets/img/photos/photo3@2x.jpg');">
                    <div class="push-50-t push-15">
                        <h1 class="h2 text-white animated zoomIn">Dashboard</h1>
                        <h2 class="h5 text-white-op animated zoomIn">Welcome Administrator</h2>
                    </div>
                </div>
                <!-- END Page Header -->
                <!-- Stats -->
                <div class="content bg-white border-b">
                    <div class="row items-push text-uppercase">
                        <div class="col-xs-6 col-sm-3">
                            <div class="font-w700 text-gray-darker animated fadeIn">Product Sales</div>
                            <div class="text-muted animated fadeIn"><small><i class="si si-calendar"></i> Today</small></div>
                            <a class="h2 font-w300 text-primary animated flipInX" >0</a>
                        </div>
                        <div class="col-xs-6 col-sm-3">
                            <div class="font-w700 text-gray-darker animated fadeIn">Total Sales</div>
                            <div class="text-muted animated fadeIn"><small><i class="si si-calendar"></i> All Time</small></div>
                            <a class="h2 font-w300 text-primary animated flipInX" >0</a>
                        </div>
                        <div class="col-xs-6 col-sm-3">
                            <div class="font-w700 text-gray-darker animated fadeIn">Total Earnings</div>
                            <div class="text-muted animated fadeIn"><small><i class="si si-calendar"></i> All Time</small></div>
                            <a class="h2 font-w300 text-primary animated flipInX" >
                             Rs.                                </a>
                        </div>
                        <div class="col-xs-6 col-sm-3">
                            <div class="font-w700 text-gray-darker animated fadeIn">Average Sale</div>
                            <div class="text-muted animated fadeIn"><small><i class="si si-calendar"></i> All Time</small></div>
                            <a class="h2 font-w300 text-primary animated flipInX" >
                                Rs.  
<div style="border:1px solid #990000;padding-left:20px;margin:0 0 10px 0;">

<!--<h4>A PHP Error was encountered</h4>

 <p>Severity: Warning</p>
<p>Message:  Division by zero</p>
<p>Filename: admin/dashboard.php</p>
<p>Line Number: 75</p>


  <p>Backtrace:</p> -->
  
    
  
    
  
    <!-- 
      <p style="margin-left:10px">
      File: C:\xampp\htdocs\ecom\application\views\admin\dashboard.php<br />
      Line: 75<br />
      Function: _error_handler      </p>
 -->
    
  
    
  
    
  
    
      <!-- <p style="margin-left:10px">
      File: C:\xampp\htdocs\ecom\application\controllers\admin\Dashboard.php<br />
      Line: 29<br />
      Function: view      </p>
 -->
    
  
    
  
    
  
    
     <!--  <p style="margin-left:10px">
      File: C:\xampp\htdocs\ecom\index.php<br />
      Line: 315<br />
      Function: require_once      </p> 
</div> -->                           </a>
                        </div>
                    </div>
                </div>
                <!-- END Stats -->
            <!-- Page Content -->
                    <!-- Page Header -->
                <!-- <div class="content">
             
                    <div class="block">
                        
                         <div class="block-header">
                            <h3 class="block-title col-lg-6" style="text-align: left;">
                            Today  Sales Report 
                            </h3>
                            <span class="col-lg-6" style="text-align: right;">
                                  
                            </span>
                        </div> -->
                   <!--  <div class="col-md-12" style="padding-top: 20px;"></div>
                    <div class="block-content">
                            <table class="table table-bordered table-striped js-dataTable-full">
                                <thead>
                                    <tr>
                                        <th>Order Number</th>
                                        <th>Order Date</th>
                                        <th>Due Date</th>
                                        <th>Created By</th>
                                        <th>Buyer Name</th>
                                        <th>Cash Discount</th>
                                        <th>Grand Amount</th>
                                        <th>No of item</th>
                                        <th>Net</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                                                    </tbody>
                            </table>
                        </div>
                    </div> -->
                 

                 
                  <!--   <div class="block">
                        
                         <div class="block-header">
                            <h3 class="block-title col-lg-6" style="text-align: left;">
                            Today New User Register
                            </h3>
                            <span class="col-lg-6" style="text-align: right;">
                                  
                            </span>
                        </div>
                    <div class="col-md-12" style="padding-top: 20px;"></div>
                    <div class="block-content">
                            <table class="table table-bordered table-striped js-dataTable-full">
                                <thead>
                                    <tr>
                                        <th>Customer Id</th>
                                        <th>First Name</th>
                                        <th>Last Name</th>
                                        <th>Email</th>
                                        <th>Password</th>
                                        <th>Phone</th>
                                        <th>Created By</th>
                                        <th>Created Date</th>
                                    </tr>
                                </thead>
                                <tbody>
                                                                    </tbody>
                            </table>
                        </div>
                    </div>
                 

                 
                </div>
                    
                </div> -->
                <!-- END Page Content -->
            </main>
            <!-- END Main Container -->
            
