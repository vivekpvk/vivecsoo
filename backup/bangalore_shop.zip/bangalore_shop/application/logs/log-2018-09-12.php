<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-09-12 07:21:54 --> 404 Page Not Found: Images/goslogo.png
ERROR - 2018-09-12 07:25:52 --> 404 Page Not Found: admin//index
ERROR - 2018-09-12 07:53:03 --> 404 Page Not Found: Assets/css
ERROR - 2018-09-12 07:53:23 --> 404 Page Not Found: Assets/css
ERROR - 2018-09-12 09:51:38 --> 404 Page Not Found: User/test
ERROR - 2018-09-12 12:33:33 --> 404 Page Not Found: Images/goslogo.png
ERROR - 2018-09-12 12:39:41 --> 404 Page Not Found: Assets/js
ERROR - 2018-09-12 12:39:41 --> 404 Page Not Found: Assets/css
