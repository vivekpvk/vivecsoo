<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-09-11 08:12:57 --> 404 Page Not Found: admin//index
ERROR - 2018-09-11 08:12:59 --> 404 Page Not Found: admin//index
ERROR - 2018-09-11 08:13:00 --> 404 Page Not Found: admin//index
ERROR - 2018-09-11 08:13:00 --> 404 Page Not Found: admin//index
ERROR - 2018-09-11 08:13:00 --> 404 Page Not Found: admin//index
ERROR - 2018-09-11 08:13:00 --> 404 Page Not Found: admin//index
ERROR - 2018-09-11 08:13:06 --> 404 Page Not Found: Assets/js
ERROR - 2018-09-11 08:13:07 --> 404 Page Not Found: Assets/css
ERROR - 2018-09-11 08:13:07 --> 404 Page Not Found: Assets/css
ERROR - 2018-09-11 08:13:07 --> 404 Page Not Found: Assets/js
ERROR - 2018-09-11 08:13:07 --> 404 Page Not Found: Assets/js
ERROR - 2018-09-11 08:13:07 --> 404 Page Not Found: Assets/js
ERROR - 2018-09-11 08:13:07 --> 404 Page Not Found: Assets/js
ERROR - 2018-09-11 08:13:07 --> 404 Page Not Found: Assets/js
ERROR - 2018-09-11 08:13:07 --> 404 Page Not Found: Assets/js
ERROR - 2018-09-11 08:13:07 --> 404 Page Not Found: Assets/js
ERROR - 2018-09-11 08:13:07 --> 404 Page Not Found: Assets/js
ERROR - 2018-09-11 08:13:07 --> 404 Page Not Found: Assets/js
ERROR - 2018-09-11 08:13:07 --> 404 Page Not Found: Assets/js
ERROR - 2018-09-11 08:13:07 --> 404 Page Not Found: Assets/js
ERROR - 2018-09-11 08:13:07 --> 404 Page Not Found: Assets/js
ERROR - 2018-09-11 08:13:07 --> 404 Page Not Found: Assets/js
ERROR - 2018-09-11 08:13:07 --> 404 Page Not Found: Assets/js
ERROR - 2018-09-11 08:13:07 --> 404 Page Not Found: Assets/js
ERROR - 2018-09-11 08:13:07 --> 404 Page Not Found: Assets/js
ERROR - 2018-09-11 08:13:07 --> 404 Page Not Found: Assets/js
ERROR - 2018-09-11 08:13:07 --> 404 Page Not Found: Assets/js
ERROR - 2018-09-11 08:13:07 --> 404 Page Not Found: Assets/js
ERROR - 2018-09-11 08:13:07 --> 404 Page Not Found: Assets/js
ERROR - 2018-09-11 08:31:00 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\bangalore_shop\application\views\admin\admin_list.php 34
ERROR - 2018-09-11 08:31:00 --> Severity: Notice --> Undefined property: stdClass::$lastname C:\xampp\htdocs\bangalore_shop\application\views\admin\admin_list.php 35
ERROR - 2018-09-11 08:31:00 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\bangalore_shop\application\views\admin\admin_list.php 38
ERROR - 2018-09-11 08:31:00 --> Severity: Notice --> Undefined property: stdClass::$role C:\xampp\htdocs\bangalore_shop\application\views\admin\admin_list.php 40
ERROR - 2018-09-11 08:35:31 --> 404 Page Not Found: admin/Login/css
ERROR - 2018-09-11 08:35:31 --> 404 Page Not Found: admin/Login/css
ERROR - 2018-09-11 08:35:31 --> 404 Page Not Found: admin/Login/js
ERROR - 2018-09-11 08:35:31 --> 404 Page Not Found: admin/Login/js
ERROR - 2018-09-11 08:35:31 --> 404 Page Not Found: admin/Login/favicon.ico
ERROR - 2018-09-11 09:02:46 --> 404 Page Not Found: Images/goslogo.png
ERROR - 2018-09-11 09:03:36 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\bangalore_shop\application\controllers\admin\Login.php 51
ERROR - 2018-09-11 09:03:50 --> 404 Page Not Found: Assets/css
ERROR - 2018-09-11 09:06:25 --> 404 Page Not Found: Assets/css
ERROR - 2018-09-11 09:22:57 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\bangalore_shop\application\views\admin\admin_list.php 34
ERROR - 2018-09-11 09:22:57 --> Severity: Notice --> Undefined property: stdClass::$lastname C:\xampp\htdocs\bangalore_shop\application\views\admin\admin_list.php 35
ERROR - 2018-09-11 09:22:57 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\bangalore_shop\application\views\admin\admin_list.php 38
ERROR - 2018-09-11 09:22:57 --> Severity: Notice --> Undefined property: stdClass::$role C:\xampp\htdocs\bangalore_shop\application\views\admin\admin_list.php 40
ERROR - 2018-09-11 09:23:08 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\bangalore_shop\application\views\admin\admin_list.php 34
ERROR - 2018-09-11 09:23:08 --> Severity: Notice --> Undefined property: stdClass::$lastname C:\xampp\htdocs\bangalore_shop\application\views\admin\admin_list.php 35
ERROR - 2018-09-11 09:23:08 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\bangalore_shop\application\views\admin\admin_list.php 38
ERROR - 2018-09-11 09:23:08 --> Severity: Notice --> Undefined property: stdClass::$role C:\xampp\htdocs\bangalore_shop\application\views\admin\admin_list.php 40
ERROR - 2018-09-11 09:24:23 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\bangalore_shop\application\views\admin\admin_list.php 34
ERROR - 2018-09-11 09:24:23 --> Severity: Notice --> Undefined property: stdClass::$lastname C:\xampp\htdocs\bangalore_shop\application\views\admin\admin_list.php 35
ERROR - 2018-09-11 09:24:23 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\bangalore_shop\application\views\admin\admin_list.php 38
ERROR - 2018-09-11 09:24:23 --> Severity: Notice --> Undefined property: stdClass::$role C:\xampp\htdocs\bangalore_shop\application\views\admin\admin_list.php 40
ERROR - 2018-09-11 09:24:27 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\bangalore_shop\application\views\admin\admin_list.php 34
ERROR - 2018-09-11 09:24:27 --> Severity: Notice --> Undefined property: stdClass::$lastname C:\xampp\htdocs\bangalore_shop\application\views\admin\admin_list.php 35
ERROR - 2018-09-11 09:24:27 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\bangalore_shop\application\views\admin\admin_list.php 38
ERROR - 2018-09-11 09:24:27 --> Severity: Notice --> Undefined property: stdClass::$role C:\xampp\htdocs\bangalore_shop\application\views\admin\admin_list.php 40
ERROR - 2018-09-11 09:24:59 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\bangalore_shop\application\views\admin\admin_list.php 34
ERROR - 2018-09-11 09:24:59 --> Severity: Notice --> Undefined property: stdClass::$lastname C:\xampp\htdocs\bangalore_shop\application\views\admin\admin_list.php 35
ERROR - 2018-09-11 09:24:59 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\bangalore_shop\application\views\admin\admin_list.php 38
ERROR - 2018-09-11 09:24:59 --> Severity: Notice --> Undefined property: stdClass::$role C:\xampp\htdocs\bangalore_shop\application\views\admin\admin_list.php 40
ERROR - 2018-09-11 09:25:02 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\bangalore_shop\application\views\admin\admin_list.php 34
ERROR - 2018-09-11 09:25:02 --> Severity: Notice --> Undefined property: stdClass::$lastname C:\xampp\htdocs\bangalore_shop\application\views\admin\admin_list.php 35
ERROR - 2018-09-11 09:25:02 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\bangalore_shop\application\views\admin\admin_list.php 38
ERROR - 2018-09-11 09:25:02 --> Severity: Notice --> Undefined property: stdClass::$role C:\xampp\htdocs\bangalore_shop\application\views\admin\admin_list.php 40
ERROR - 2018-09-11 09:28:26 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' C:\xampp\htdocs\bangalore_shop\application\views\admin\admin_list.php 42
ERROR - 2018-09-11 10:04:14 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\bangalore_shop\application\controllers\admin\Register.php 33
ERROR - 2018-09-11 10:49:37 --> Severity: error --> Exception: syntax error, unexpected '}' C:\xampp\htdocs\bangalore_shop\application\controllers\admin\Register.php 55
ERROR - 2018-09-11 10:49:47 --> 404 Page Not Found: Newadmin/index
ERROR - 2018-09-11 10:51:21 --> 404 Page Not Found: Newadmin/index
ERROR - 2018-09-11 10:51:22 --> 404 Page Not Found: Newadmin/index
ERROR - 2018-09-11 10:51:22 --> 404 Page Not Found: Newadmin/index
ERROR - 2018-09-11 10:55:01 --> Severity: error --> Exception: Unable to locate the model you have specified: Cat_model C:\xampp\htdocs\bangalore_shop\system\core\Loader.php 348
ERROR - 2018-09-11 10:55:54 --> Severity: error --> Exception: Unable to locate the model you have specified: Brand_model C:\xampp\htdocs\bangalore_shop\system\core\Loader.php 348
ERROR - 2018-09-11 11:00:32 --> Severity: error --> Exception: syntax error, unexpected '}' C:\xampp\htdocs\bangalore_shop\application\controllers\admin\Register.php 33
ERROR - 2018-09-11 11:00:43 --> Severity: error --> Exception: syntax error, unexpected '}' C:\xampp\htdocs\bangalore_shop\application\controllers\admin\Register.php 56
ERROR - 2018-09-11 11:00:44 --> Severity: error --> Exception: syntax error, unexpected '}' C:\xampp\htdocs\bangalore_shop\application\controllers\admin\Register.php 56
ERROR - 2018-09-11 11:00:45 --> Severity: error --> Exception: syntax error, unexpected '}' C:\xampp\htdocs\bangalore_shop\application\controllers\admin\Register.php 56
ERROR - 2018-09-11 11:00:45 --> Severity: error --> Exception: syntax error, unexpected '}' C:\xampp\htdocs\bangalore_shop\application\controllers\admin\Register.php 56
ERROR - 2018-09-11 11:00:45 --> Severity: error --> Exception: syntax error, unexpected '}' C:\xampp\htdocs\bangalore_shop\application\controllers\admin\Register.php 56
ERROR - 2018-09-11 11:00:45 --> Severity: error --> Exception: syntax error, unexpected '}' C:\xampp\htdocs\bangalore_shop\application\controllers\admin\Register.php 56
ERROR - 2018-09-11 11:00:45 --> Severity: error --> Exception: syntax error, unexpected '}' C:\xampp\htdocs\bangalore_shop\application\controllers\admin\Register.php 56
ERROR - 2018-09-11 11:00:46 --> Severity: error --> Exception: syntax error, unexpected '}' C:\xampp\htdocs\bangalore_shop\application\controllers\admin\Register.php 56
ERROR - 2018-09-11 11:00:46 --> Severity: error --> Exception: syntax error, unexpected '}' C:\xampp\htdocs\bangalore_shop\application\controllers\admin\Register.php 56
ERROR - 2018-09-11 11:00:46 --> Severity: error --> Exception: syntax error, unexpected '}' C:\xampp\htdocs\bangalore_shop\application\controllers\admin\Register.php 56
ERROR - 2018-09-11 11:04:21 --> Severity: error --> Exception: Unable to locate the model you have specified: Brand_model C:\xampp\htdocs\bangalore_shop\system\core\Loader.php 348
ERROR - 2018-09-11 11:08:20 --> 404 Page Not Found: Images/product_image.gif
ERROR - 2018-09-11 11:21:25 --> Severity: error --> Exception: syntax error, unexpected ''modified_at'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\xampp\htdocs\bangalore_shop\application\controllers\admin\category\Categoryadd.php 43
ERROR - 2018-09-11 11:21:26 --> Severity: error --> Exception: syntax error, unexpected ''modified_at'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\xampp\htdocs\bangalore_shop\application\controllers\admin\category\Categoryadd.php 43
ERROR - 2018-09-11 11:21:26 --> Severity: error --> Exception: syntax error, unexpected ''modified_at'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\xampp\htdocs\bangalore_shop\application\controllers\admin\category\Categoryadd.php 43
ERROR - 2018-09-11 11:21:26 --> Severity: error --> Exception: syntax error, unexpected ''modified_at'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\xampp\htdocs\bangalore_shop\application\controllers\admin\category\Categoryadd.php 43
ERROR - 2018-09-11 11:21:27 --> Severity: error --> Exception: syntax error, unexpected ''modified_at'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\xampp\htdocs\bangalore_shop\application\controllers\admin\category\Categoryadd.php 43
ERROR - 2018-09-11 11:21:27 --> Severity: error --> Exception: syntax error, unexpected ''modified_at'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\xampp\htdocs\bangalore_shop\application\controllers\admin\category\Categoryadd.php 43
ERROR - 2018-09-11 11:22:19 --> Severity: 4096 --> Object of class Categoryadd could not be converted to string C:\xampp\htdocs\bangalore_shop\application\controllers\admin\category\Categoryadd.php 47
ERROR - 2018-09-11 11:22:19 --> Severity: Notice --> Undefined variable:  C:\xampp\htdocs\bangalore_shop\application\controllers\admin\category\Categoryadd.php 47
ERROR - 2018-09-11 11:22:19 --> Severity: Notice --> Trying to get property 'session' of non-object C:\xampp\htdocs\bangalore_shop\application\controllers\admin\category\Categoryadd.php 47
ERROR - 2018-09-11 11:22:19 --> Severity: error --> Exception: Call to a member function set_flashdata() on null C:\xampp\htdocs\bangalore_shop\application\controllers\admin\category\Categoryadd.php 47
ERROR - 2018-09-11 11:23:08 --> Severity: 4096 --> Object of class Categoryadd could not be converted to string C:\xampp\htdocs\bangalore_shop\application\controllers\admin\category\Categoryadd.php 47
ERROR - 2018-09-11 11:23:08 --> Severity: Notice --> Undefined variable:  C:\xampp\htdocs\bangalore_shop\application\controllers\admin\category\Categoryadd.php 47
ERROR - 2018-09-11 11:23:08 --> Severity: Notice --> Trying to get property 'session' of non-object C:\xampp\htdocs\bangalore_shop\application\controllers\admin\category\Categoryadd.php 47
ERROR - 2018-09-11 11:23:08 --> Severity: error --> Exception: Call to a member function set_flashdata() on null C:\xampp\htdocs\bangalore_shop\application\controllers\admin\category\Categoryadd.php 47
ERROR - 2018-09-11 11:24:17 --> 404 Page Not Found: admin/category/Cat_list/index
ERROR - 2018-09-11 11:24:50 --> 404 Page Not Found: admin/category/Cat_list/index
ERROR - 2018-09-11 11:24:57 --> 404 Page Not Found: admin/Categoryadd/cat_list
ERROR - 2018-09-11 11:25:02 --> 404 Page Not Found: admin/Categoryadd/cat_list
ERROR - 2018-09-11 11:25:13 --> Severity: Notice --> Undefined property: stdClass::$catparent_id C:\xampp\htdocs\bangalore_shop\application\views\admin\category\cat_list.php 51
ERROR - 2018-09-11 11:25:13 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\bangalore_shop\application\views\admin\category\cat_list.php 60
ERROR - 2018-09-11 11:25:13 --> Severity: Notice --> Undefined property: stdClass::$image C:\xampp\htdocs\bangalore_shop\application\views\admin\category\cat_list.php 61
ERROR - 2018-09-11 11:25:13 --> Severity: Notice --> Undefined property: stdClass::$image C:\xampp\htdocs\bangalore_shop\application\views\admin\category\cat_list.php 62
ERROR - 2018-09-11 11:25:13 --> Severity: Notice --> Undefined property: stdClass::$created_by C:\xampp\htdocs\bangalore_shop\application\views\admin\category\cat_list.php 63
ERROR - 2018-09-11 11:25:13 --> Severity: Notice --> Undefined property: stdClass::$catparent_id C:\xampp\htdocs\bangalore_shop\application\views\admin\category\cat_list.php 51
ERROR - 2018-09-11 11:25:13 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\bangalore_shop\application\views\admin\category\cat_list.php 60
ERROR - 2018-09-11 11:25:13 --> Severity: Notice --> Undefined property: stdClass::$image C:\xampp\htdocs\bangalore_shop\application\views\admin\category\cat_list.php 61
ERROR - 2018-09-11 11:25:13 --> Severity: Notice --> Undefined property: stdClass::$image C:\xampp\htdocs\bangalore_shop\application\views\admin\category\cat_list.php 62
ERROR - 2018-09-11 11:25:13 --> Severity: Notice --> Undefined property: stdClass::$created_by C:\xampp\htdocs\bangalore_shop\application\views\admin\category\cat_list.php 63
ERROR - 2018-09-11 11:25:13 --> Severity: Notice --> Undefined property: stdClass::$catparent_id C:\xampp\htdocs\bangalore_shop\application\views\admin\category\cat_list.php 51
ERROR - 2018-09-11 11:25:13 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\bangalore_shop\application\views\admin\category\cat_list.php 60
ERROR - 2018-09-11 11:25:13 --> Severity: Notice --> Undefined property: stdClass::$image C:\xampp\htdocs\bangalore_shop\application\views\admin\category\cat_list.php 61
ERROR - 2018-09-11 11:25:13 --> Severity: Notice --> Undefined property: stdClass::$image C:\xampp\htdocs\bangalore_shop\application\views\admin\category\cat_list.php 62
ERROR - 2018-09-11 11:25:13 --> Severity: Notice --> Undefined property: stdClass::$created_by C:\xampp\htdocs\bangalore_shop\application\views\admin\category\cat_list.php 63
ERROR - 2018-09-11 11:25:13 --> Severity: Notice --> Undefined property: stdClass::$catparent_id C:\xampp\htdocs\bangalore_shop\application\views\admin\category\cat_list.php 51
ERROR - 2018-09-11 11:25:13 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\bangalore_shop\application\views\admin\category\cat_list.php 60
ERROR - 2018-09-11 11:25:13 --> Severity: Notice --> Undefined property: stdClass::$image C:\xampp\htdocs\bangalore_shop\application\views\admin\category\cat_list.php 61
ERROR - 2018-09-11 11:25:13 --> Severity: Notice --> Undefined property: stdClass::$image C:\xampp\htdocs\bangalore_shop\application\views\admin\category\cat_list.php 62
ERROR - 2018-09-11 11:25:13 --> Severity: Notice --> Undefined property: stdClass::$created_by C:\xampp\htdocs\bangalore_shop\application\views\admin\category\cat_list.php 63
ERROR - 2018-09-11 11:25:13 --> Severity: Notice --> Undefined property: stdClass::$catparent_id C:\xampp\htdocs\bangalore_shop\application\views\admin\category\cat_list.php 51
ERROR - 2018-09-11 11:25:13 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\bangalore_shop\application\views\admin\category\cat_list.php 60
ERROR - 2018-09-11 11:25:13 --> Severity: Notice --> Undefined property: stdClass::$image C:\xampp\htdocs\bangalore_shop\application\views\admin\category\cat_list.php 61
ERROR - 2018-09-11 11:25:13 --> Severity: Notice --> Undefined property: stdClass::$image C:\xampp\htdocs\bangalore_shop\application\views\admin\category\cat_list.php 62
ERROR - 2018-09-11 11:25:13 --> Severity: Notice --> Undefined property: stdClass::$created_by C:\xampp\htdocs\bangalore_shop\application\views\admin\category\cat_list.php 63
ERROR - 2018-09-11 11:25:27 --> 404 Page Not Found: admin/Categoryadd/cat_list
ERROR - 2018-09-11 11:25:47 --> Severity: Notice --> Undefined property: stdClass::$catparent_id C:\xampp\htdocs\bangalore_shop\application\views\admin\category\cat_list.php 51
ERROR - 2018-09-11 11:25:47 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\bangalore_shop\application\views\admin\category\cat_list.php 60
ERROR - 2018-09-11 11:25:47 --> Severity: Notice --> Undefined property: stdClass::$image C:\xampp\htdocs\bangalore_shop\application\views\admin\category\cat_list.php 61
ERROR - 2018-09-11 11:25:47 --> Severity: Notice --> Undefined property: stdClass::$image C:\xampp\htdocs\bangalore_shop\application\views\admin\category\cat_list.php 62
ERROR - 2018-09-11 11:25:47 --> Severity: Notice --> Undefined property: stdClass::$created_by C:\xampp\htdocs\bangalore_shop\application\views\admin\category\cat_list.php 63
ERROR - 2018-09-11 11:25:47 --> Severity: Notice --> Undefined property: stdClass::$catparent_id C:\xampp\htdocs\bangalore_shop\application\views\admin\category\cat_list.php 51
ERROR - 2018-09-11 11:25:47 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\bangalore_shop\application\views\admin\category\cat_list.php 60
ERROR - 2018-09-11 11:25:47 --> Severity: Notice --> Undefined property: stdClass::$image C:\xampp\htdocs\bangalore_shop\application\views\admin\category\cat_list.php 61
ERROR - 2018-09-11 11:25:47 --> Severity: Notice --> Undefined property: stdClass::$image C:\xampp\htdocs\bangalore_shop\application\views\admin\category\cat_list.php 62
ERROR - 2018-09-11 11:25:47 --> Severity: Notice --> Undefined property: stdClass::$created_by C:\xampp\htdocs\bangalore_shop\application\views\admin\category\cat_list.php 63
ERROR - 2018-09-11 11:25:47 --> Severity: Notice --> Undefined property: stdClass::$catparent_id C:\xampp\htdocs\bangalore_shop\application\views\admin\category\cat_list.php 51
ERROR - 2018-09-11 11:25:47 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\bangalore_shop\application\views\admin\category\cat_list.php 60
ERROR - 2018-09-11 11:25:47 --> Severity: Notice --> Undefined property: stdClass::$image C:\xampp\htdocs\bangalore_shop\application\views\admin\category\cat_list.php 61
ERROR - 2018-09-11 11:25:47 --> Severity: Notice --> Undefined property: stdClass::$image C:\xampp\htdocs\bangalore_shop\application\views\admin\category\cat_list.php 62
ERROR - 2018-09-11 11:25:47 --> Severity: Notice --> Undefined property: stdClass::$created_by C:\xampp\htdocs\bangalore_shop\application\views\admin\category\cat_list.php 63
ERROR - 2018-09-11 11:25:47 --> Severity: Notice --> Undefined property: stdClass::$catparent_id C:\xampp\htdocs\bangalore_shop\application\views\admin\category\cat_list.php 51
ERROR - 2018-09-11 11:25:47 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\bangalore_shop\application\views\admin\category\cat_list.php 60
ERROR - 2018-09-11 11:25:47 --> Severity: Notice --> Undefined property: stdClass::$image C:\xampp\htdocs\bangalore_shop\application\views\admin\category\cat_list.php 61
ERROR - 2018-09-11 11:25:47 --> Severity: Notice --> Undefined property: stdClass::$image C:\xampp\htdocs\bangalore_shop\application\views\admin\category\cat_list.php 62
ERROR - 2018-09-11 11:25:47 --> Severity: Notice --> Undefined property: stdClass::$created_by C:\xampp\htdocs\bangalore_shop\application\views\admin\category\cat_list.php 63
ERROR - 2018-09-11 11:25:47 --> Severity: Notice --> Undefined property: stdClass::$catparent_id C:\xampp\htdocs\bangalore_shop\application\views\admin\category\cat_list.php 51
ERROR - 2018-09-11 11:25:47 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\bangalore_shop\application\views\admin\category\cat_list.php 60
ERROR - 2018-09-11 11:25:47 --> Severity: Notice --> Undefined property: stdClass::$image C:\xampp\htdocs\bangalore_shop\application\views\admin\category\cat_list.php 61
ERROR - 2018-09-11 11:25:47 --> Severity: Notice --> Undefined property: stdClass::$image C:\xampp\htdocs\bangalore_shop\application\views\admin\category\cat_list.php 62
ERROR - 2018-09-11 11:25:47 --> Severity: Notice --> Undefined property: stdClass::$created_by C:\xampp\htdocs\bangalore_shop\application\views\admin\category\cat_list.php 63
ERROR - 2018-09-11 11:25:47 --> Severity: Notice --> Undefined property: stdClass::$catparent_id C:\xampp\htdocs\bangalore_shop\application\views\admin\category\cat_list.php 51
ERROR - 2018-09-11 11:25:47 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\bangalore_shop\application\views\admin\category\cat_list.php 60
ERROR - 2018-09-11 11:25:47 --> Severity: Notice --> Undefined property: stdClass::$image C:\xampp\htdocs\bangalore_shop\application\views\admin\category\cat_list.php 61
ERROR - 2018-09-11 11:25:47 --> Severity: Notice --> Undefined property: stdClass::$image C:\xampp\htdocs\bangalore_shop\application\views\admin\category\cat_list.php 62
ERROR - 2018-09-11 11:25:47 --> Severity: Notice --> Undefined property: stdClass::$created_by C:\xampp\htdocs\bangalore_shop\application\views\admin\category\cat_list.php 63
ERROR - 2018-09-11 11:25:47 --> Severity: Notice --> Undefined property: stdClass::$catparent_id C:\xampp\htdocs\bangalore_shop\application\views\admin\category\cat_list.php 51
ERROR - 2018-09-11 11:25:47 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\bangalore_shop\application\views\admin\category\cat_list.php 60
ERROR - 2018-09-11 11:25:47 --> Severity: Notice --> Undefined property: stdClass::$image C:\xampp\htdocs\bangalore_shop\application\views\admin\category\cat_list.php 61
ERROR - 2018-09-11 11:25:47 --> Severity: Notice --> Undefined property: stdClass::$image C:\xampp\htdocs\bangalore_shop\application\views\admin\category\cat_list.php 62
ERROR - 2018-09-11 11:25:47 --> Severity: Notice --> Undefined property: stdClass::$created_by C:\xampp\htdocs\bangalore_shop\application\views\admin\category\cat_list.php 63
ERROR - 2018-09-11 11:31:13 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\bangalore_shop\application\views\admin\category\cat_edit.php 42
ERROR - 2018-09-11 11:31:13 --> Severity: Notice --> Undefined property: stdClass::$image C:\xampp\htdocs\bangalore_shop\application\views\admin\category\cat_edit.php 51
ERROR - 2018-09-11 11:31:13 --> Severity: Notice --> Undefined property: stdClass::$parent_id C:\xampp\htdocs\bangalore_shop\application\views\admin\category\cat_edit.php 65
ERROR - 2018-09-11 11:31:13 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\bangalore_shop\application\views\admin\category\cat_edit.php 65
ERROR - 2018-09-11 11:34:25 --> Severity: Notice --> Undefined index: image C:\xampp\htdocs\bangalore_shop\application\controllers\admin\category\Categoryadd.php 104
ERROR - 2018-09-11 11:34:25 --> Query error: Unknown column 'name' in 'field list' - Invalid query: UPDATE `category` SET `name` = '20%', `parent_id` = NULL, `modified_at` = '2018-09-11 11:34:25', `status` = '0'
WHERE `id` = '8'
ERROR - 2018-09-11 12:10:38 --> 404 Page Not Found: Images/product_image.gif
ERROR - 2018-09-11 12:46:13 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\bangalore_shop\application\controllers\admin\product\Productadd.php 59
ERROR - 2018-09-11 12:46:13 --> The upload path does not appear to be valid.
ERROR - 2018-09-11 12:46:13 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\bangalore_shop\application\controllers\admin\product\Productadd.php 67
ERROR - 2018-09-11 12:46:13 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\bangalore_shop\application\controllers\admin\product\Productadd.php 67
ERROR - 2018-09-11 12:46:13 --> Severity: Warning --> getimagesize(./upload/Array/acer predator notebook gaming utility backpack.jpg): failed to open stream: No such file or directory C:\xampp\htdocs\bangalore_shop\application\models\Common_model.php 12
ERROR - 2018-09-11 12:47:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\bangalore_shop\application\controllers\admin\product\Productadd.php 59
ERROR - 2018-09-11 12:47:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\bangalore_shop\application\controllers\admin\product\Productadd.php 67
ERROR - 2018-09-11 12:47:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\bangalore_shop\application\controllers\admin\product\Productadd.php 67
ERROR - 2018-09-11 12:47:09 --> Query error: Unknown column 'image' in 'field list' - Invalid query: INSERT INTO `products` (`image`, `prod_name`, `cat_id`, `prod_brand`, `prod_url`, `company`, `description`, `specification`, `created_at`, `status`) VALUES ('acer_predator_notebook_gaming_utility_backpack.jpg', 'sefrewfte', '1', 'ertger', 'tertert', 'tertret', 'sdrtetfge', 'rtgertert', '2018-09-11 12:47:09', '1')
ERROR - 2018-09-11 12:47:40 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\bangalore_shop\application\controllers\admin\product\Productadd.php 59
ERROR - 2018-09-11 12:47:40 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\bangalore_shop\application\controllers\admin\product\Productadd.php 67
ERROR - 2018-09-11 12:47:40 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\bangalore_shop\application\controllers\admin\product\Productadd.php 67
ERROR - 2018-09-11 12:47:40 --> 404 Page Not Found: admin/product/Productadd/product_list
ERROR - 2018-09-11 13:00:54 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file C:\xampp\htdocs\bangalore_shop\application\controllers\admin\product\Productadd.php 91
ERROR - 2018-09-11 13:00:57 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file C:\xampp\htdocs\bangalore_shop\application\controllers\admin\product\Productadd.php 91
ERROR - 2018-09-11 13:01:10 --> 404 Page Not Found: Upload/brand
ERROR - 2018-09-11 13:01:19 --> 404 Page Not Found: Assets/css
ERROR - 2018-09-11 13:02:52 --> 404 Page Not Found: Upload/brand
ERROR - 2018-09-11 13:02:52 --> 404 Page Not Found: Assets/css
ERROR - 2018-09-11 13:02:59 --> 404 Page Not Found: Assets/css
ERROR - 2018-09-11 13:03:22 --> 404 Page Not Found: Upload/acer_predator_notebook_gaming_utility_backpack1.jpg
ERROR - 2018-09-11 13:03:23 --> 404 Page Not Found: Assets/css
ERROR - 2018-09-11 13:03:26 --> 404 Page Not Found: Upload/acer_predator_notebook_gaming_utility_backpack1.jpg
ERROR - 2018-09-11 13:03:30 --> 404 Page Not Found: Assets/css
ERROR - 2018-09-11 13:04:56 --> Severity: error --> Exception: Call to undefined method Product_model::getPosts() C:\xampp\htdocs\bangalore_shop\application\controllers\admin\product\Productadd.php 19
ERROR - 2018-09-11 13:05:56 --> Severity: error --> Exception: Call to undefined method Product_model::getPosts() C:\xampp\htdocs\bangalore_shop\application\controllers\admin\product\Productadd.php 19
ERROR - 2018-09-11 13:05:58 --> Severity: error --> Exception: Call to undefined method Product_model::getPosts() C:\xampp\htdocs\bangalore_shop\application\controllers\admin\product\Productadd.php 19
ERROR - 2018-09-11 13:06:19 --> 404 Page Not Found: Upload/acer_predator_notebook_gaming_utility_backpack1.jpg
ERROR - 2018-09-11 13:06:37 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\bangalore_shop\application\controllers\admin\product\Productadd.php 59
ERROR - 2018-09-11 13:06:37 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\bangalore_shop\application\controllers\admin\product\Productadd.php 67
ERROR - 2018-09-11 13:06:37 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\bangalore_shop\application\controllers\admin\product\Productadd.php 67
ERROR - 2018-09-11 13:06:37 --> 404 Page Not Found: Upload/acer_predator_notebook_gaming_utility_backpack1.jpg
ERROR - 2018-09-11 13:06:37 --> 404 Page Not Found: Upload/chrysanthemum.jpg
ERROR - 2018-09-11 13:08:50 --> 404 Page Not Found: Upload/chrysanthemum.jpg
ERROR - 2018-09-11 13:09:43 --> 404 Page Not Found: Upload/chrysanthemum.jpg
ERROR - 2018-09-11 13:09:47 --> 404 Page Not Found: Upload/acer_predator_notebook_gaming_utility_backpack1.jpg
ERROR - 2018-09-11 13:09:47 --> 404 Page Not Found: Upload/chrysanthemum.jpg
ERROR - 2018-09-11 13:10:01 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\bangalore_shop\application\controllers\admin\product\Productadd.php 59
ERROR - 2018-09-11 13:10:01 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\bangalore_shop\application\controllers\admin\product\Productadd.php 67
ERROR - 2018-09-11 13:10:01 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\bangalore_shop\application\controllers\admin\product\Productadd.php 67
ERROR - 2018-09-11 13:10:01 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\bangalore_shop\application\models\Product_model.php 9
ERROR - 2018-09-11 13:10:02 --> 404 Page Not Found: Upload/acer_predator_notebook_gaming_utility_backpack1.jpg
ERROR - 2018-09-11 13:10:02 --> 404 Page Not Found: Upload/chrysanthemum.jpg
ERROR - 2018-09-11 13:14:10 --> 404 Page Not Found: Upload/chrysanthemum.jpg
ERROR - 2018-09-11 13:14:10 --> 404 Page Not Found: Upload/acer_predator_notebook_gaming_utility_backpack1.jpg
ERROR - 2018-09-11 13:14:12 --> 404 Page Not Found: Images/goslogo.png
ERROR - 2018-09-11 13:14:31 --> 404 Page Not Found: admin/category/Variantadd/Delete_var
ERROR - 2018-09-11 13:32:40 --> 404 Page Not Found: Upload/acer_predator_notebook_gaming_utility_backpack1.jpg
ERROR - 2018-09-11 13:32:40 --> 404 Page Not Found: Upload/chrysanthemum.jpg
ERROR - 2018-09-11 13:32:43 --> 404 Page Not Found: admin/category/Variantadd/edit_var
ERROR - 2018-09-11 13:35:38 --> 404 Page Not Found: admin/category/Variantadd/edit_var
ERROR - 2018-09-11 13:35:42 --> Severity: Notice --> Undefined property: stdClass::$spec C:\xampp\htdocs\bangalore_shop\application\views\admin\product\product_edit.php 110
ERROR - 2018-09-11 13:35:42 --> 404 Page Not Found: Upload/chrysanthemum.jpg
ERROR - 2018-09-11 13:37:46 --> Severity: Notice --> Undefined property: stdClass::$spec C:\xampp\htdocs\bangalore_shop\application\views\admin\product\product_edit.php 110
ERROR - 2018-09-11 13:37:46 --> 404 Page Not Found: Upload/chrysanthemum.jpg
ERROR - 2018-09-11 13:38:53 --> Severity: Notice --> Undefined property: stdClass::$spec C:\xampp\htdocs\bangalore_shop\application\views\admin\product\product_edit.php 110
ERROR - 2018-09-11 13:38:53 --> 404 Page Not Found: Upload/chrysanthemum.jpg
ERROR - 2018-09-11 13:38:54 --> Severity: Notice --> Undefined property: stdClass::$spec C:\xampp\htdocs\bangalore_shop\application\views\admin\product\product_edit.php 110
ERROR - 2018-09-11 13:38:55 --> 404 Page Not Found: Upload/chrysanthemum.jpg
ERROR - 2018-09-11 13:39:29 --> 404 Page Not Found: Upload/chrysanthemum.jpg
ERROR - 2018-09-11 13:39:31 --> 404 Page Not Found: Upload/chrysanthemum.jpg
ERROR - 2018-09-11 13:40:13 --> 404 Page Not Found: Upload/chrysanthemum.jpg
ERROR - 2018-09-11 13:40:56 --> 404 Page Not Found: Upload/chrysanthemum.jpg
ERROR - 2018-09-11 13:44:17 --> 404 Page Not Found: Upload/chrysanthemum.jpg
ERROR - 2018-09-11 13:44:40 --> 404 Page Not Found: Upload/chrysanthemum.jpg
ERROR - 2018-09-11 13:59:12 --> 404 Page Not Found: Upload/chrysanthemum.jpg
ERROR - 2018-09-11 13:59:49 --> The upload path does not appear to be valid.
ERROR - 2018-09-11 13:59:49 --> Severity: Warning --> getimagesize(./upload/brand/2/koala.jpg): failed to open stream: No such file or directory C:\xampp\htdocs\bangalore_shop\application\models\Common_model.php 12
ERROR - 2018-09-11 14:00:11 --> The upload path does not appear to be valid.
ERROR - 2018-09-11 14:00:11 --> Severity: Warning --> getimagesize(./upload/brand/2/koala.jpg): failed to open stream: No such file or directory C:\xampp\htdocs\bangalore_shop\application\models\Common_model.php 12
ERROR - 2018-09-11 14:00:15 --> The upload path does not appear to be valid.
ERROR - 2018-09-11 14:00:15 --> Severity: Warning --> getimagesize(./upload/brand/2/koala.jpg): failed to open stream: No such file or directory C:\xampp\htdocs\bangalore_shop\application\models\Common_model.php 12
ERROR - 2018-09-11 14:00:18 --> The upload path does not appear to be valid.
ERROR - 2018-09-11 14:00:18 --> Severity: Warning --> getimagesize(./upload/brand/2/koala.jpg): failed to open stream: No such file or directory C:\xampp\htdocs\bangalore_shop\application\models\Common_model.php 12
ERROR - 2018-09-11 14:00:45 --> The upload path does not appear to be valid.
ERROR - 2018-09-11 14:00:45 --> Severity: Warning --> getimagesize(./upload/2/koala.jpg): failed to open stream: No such file or directory C:\xampp\htdocs\bangalore_shop\application\models\Common_model.php 12
ERROR - 2018-09-11 14:00:55 --> The upload path does not appear to be valid.
ERROR - 2018-09-11 14:00:55 --> Severity: Warning --> getimagesize(./upload/2/koala.jpg): failed to open stream: No such file or directory C:\xampp\htdocs\bangalore_shop\application\models\Common_model.php 12
ERROR - 2018-09-11 14:02:01 --> 404 Page Not Found: Upload/acer_predator_notebook_gaming_utility_backpack1.jpg
ERROR - 2018-09-11 14:02:01 --> 404 Page Not Found: Upload/chrysanthemum.jpg
ERROR - 2018-09-11 14:02:10 --> 404 Page Not Found: Upload/chrysanthemum.jpg
ERROR - 2018-09-11 14:02:42 --> The upload path does not appear to be valid.
ERROR - 2018-09-11 14:02:42 --> Severity: Warning --> getimagesize(./upload/2/koala.jpg): failed to open stream: No such file or directory C:\xampp\htdocs\bangalore_shop\application\models\Common_model.php 12
ERROR - 2018-09-11 14:03:49 --> The upload path does not appear to be valid.
ERROR - 2018-09-11 14:03:49 --> Severity: Warning --> getimagesize(./upload/2/koala.jpg): failed to open stream: No such file or directory C:\xampp\htdocs\bangalore_shop\application\models\Common_model.php 12
ERROR - 2018-09-11 14:03:51 --> The upload path does not appear to be valid.
ERROR - 2018-09-11 14:03:51 --> Severity: Warning --> getimagesize(./upload/2/koala.jpg): failed to open stream: No such file or directory C:\xampp\htdocs\bangalore_shop\application\models\Common_model.php 12
ERROR - 2018-09-11 14:04:28 --> The upload path does not appear to be valid.
ERROR - 2018-09-11 14:04:28 --> Severity: Warning --> getimagesize(./upload/2/koala.jpg): failed to open stream: No such file or directory C:\xampp\htdocs\bangalore_shop\application\models\Common_model.php 12
ERROR - 2018-09-11 14:04:30 --> The upload path does not appear to be valid.
ERROR - 2018-09-11 14:04:30 --> Severity: Warning --> getimagesize(./upload/2/koala.jpg): failed to open stream: No such file or directory C:\xampp\htdocs\bangalore_shop\application\models\Common_model.php 12
ERROR - 2018-09-11 14:04:30 --> The upload path does not appear to be valid.
ERROR - 2018-09-11 14:04:30 --> Severity: Warning --> getimagesize(./upload/2/koala.jpg): failed to open stream: No such file or directory C:\xampp\htdocs\bangalore_shop\application\models\Common_model.php 12
ERROR - 2018-09-11 14:04:31 --> The upload path does not appear to be valid.
ERROR - 2018-09-11 14:04:31 --> Severity: Warning --> getimagesize(./upload/2/koala.jpg): failed to open stream: No such file or directory C:\xampp\htdocs\bangalore_shop\application\models\Common_model.php 12
ERROR - 2018-09-11 14:04:32 --> The upload path does not appear to be valid.
ERROR - 2018-09-11 14:04:32 --> Severity: Warning --> getimagesize(./upload/2/koala.jpg): failed to open stream: No such file or directory C:\xampp\htdocs\bangalore_shop\application\models\Common_model.php 12
ERROR - 2018-09-11 14:04:41 --> The upload path does not appear to be valid.
ERROR - 2018-09-11 14:04:41 --> Severity: Warning --> getimagesize(./upload/2/penguins.jpg): failed to open stream: No such file or directory C:\xampp\htdocs\bangalore_shop\application\models\Common_model.php 12
ERROR - 2018-09-11 14:15:09 --> 404 Page Not Found: Upload/chrysanthemum.jpg
ERROR - 2018-09-11 14:15:09 --> 404 Page Not Found: Upload/acer_predator_notebook_gaming_utility_backpack1.jpg
ERROR - 2018-09-11 14:15:10 --> 404 Page Not Found: Images/goslogo.png
ERROR - 2018-09-11 14:15:15 --> Severity: Notice --> Undefined variable: filename C:\xampp\htdocs\bangalore_shop\application\controllers\admin\product\Productadd.php 155
ERROR - 2018-09-11 14:15:15 --> 404 Page Not Found: Upload/acer_predator_notebook_gaming_utility_backpack1.jpg
ERROR - 2018-09-11 14:15:15 --> 404 Page Not Found: Upload/chrysanthemum.jpg
ERROR - 2018-09-11 14:16:04 --> Severity: Notice --> Undefined variable: filename C:\xampp\htdocs\bangalore_shop\application\controllers\admin\product\Productadd.php 155
ERROR - 2018-09-11 14:16:05 --> 404 Page Not Found: Upload/chrysanthemum.jpg
ERROR - 2018-09-11 14:16:05 --> 404 Page Not Found: Upload/acer_predator_notebook_gaming_utility_backpack1.jpg
ERROR - 2018-09-11 14:16:21 --> Severity: Notice --> Undefined variable: filename C:\xampp\htdocs\bangalore_shop\application\controllers\admin\product\Productadd.php 155
ERROR - 2018-09-11 14:16:21 --> 404 Page Not Found: Upload/acer_predator_notebook_gaming_utility_backpack1.jpg
ERROR - 2018-09-11 14:16:21 --> 404 Page Not Found: Upload/chrysanthemum.jpg
ERROR - 2018-09-11 14:16:32 --> The upload path does not appear to be valid.
ERROR - 2018-09-11 14:16:32 --> Severity: Warning --> getimagesize(./upload/3/desert.jpg): failed to open stream: No such file or directory C:\xampp\htdocs\bangalore_shop\application\models\Common_model.php 12
ERROR - 2018-09-11 14:16:37 --> 404 Page Not Found: Upload/chrysanthemum.jpg
ERROR - 2018-09-11 14:16:37 --> 404 Page Not Found: Upload/acer_predator_notebook_gaming_utility_backpack1.jpg
ERROR - 2018-09-11 14:16:43 --> 404 Page Not Found: Upload/chrysanthemum.jpg
ERROR - 2018-09-11 14:16:47 --> Severity: Notice --> Undefined variable: filename C:\xampp\htdocs\bangalore_shop\application\controllers\admin\product\Productadd.php 155
ERROR - 2018-09-11 14:16:47 --> 404 Page Not Found: Upload/acer_predator_notebook_gaming_utility_backpack1.jpg
ERROR - 2018-09-11 14:16:47 --> 404 Page Not Found: Upload/chrysanthemum.jpg
ERROR - 2018-09-11 14:17:49 --> 404 Page Not Found: Upload/acer_predator_notebook_gaming_utility_backpack1.jpg
ERROR - 2018-09-11 14:17:49 --> 404 Page Not Found: Upload/chrysanthemum.jpg
ERROR - 2018-09-11 14:17:53 --> 404 Page Not Found: Upload/chrysanthemum.jpg
ERROR - 2018-09-11 14:17:59 --> The upload path does not appear to be valid.
ERROR - 2018-09-11 14:17:59 --> Severity: Warning --> getimagesize(./upload/2/tulips.jpg): failed to open stream: No such file or directory C:\xampp\htdocs\bangalore_shop\application\models\Common_model.php 12
ERROR - 2018-09-11 14:18:56 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\bangalore_shop\application\controllers\admin\product\Productadd.php 144
ERROR - 2018-09-11 14:18:56 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\bangalore_shop\application\controllers\admin\product\Productadd.php 152
ERROR - 2018-09-11 14:18:56 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\bangalore_shop\application\controllers\admin\product\Productadd.php 152
ERROR - 2018-09-11 14:18:56 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\bangalore_shop\application\controllers\admin\product\Productadd.php 153
ERROR - 2018-09-11 14:18:56 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\bangalore_shop\application\models\Product_model.php 41
ERROR - 2018-09-11 14:18:56 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\bangalore_shop\system\database\DB_query_builder.php 2442
ERROR - 2018-09-11 14:18:56 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: UPDATE `products` SET `prod_image` = 'Array/Array/tulips.jpg', `prod_name` = 'cgdfgaaaa', `cat_id` = '1', `prod_brand` = 'fghdfg', `prod_url` = 'fdg', `company` = 'dfgdfg', `description` = 'dfgdfg', `specification` = 'fdgdfgdf', `modified_at` = '2018-09-11 14:18:56', `status` = '1'
WHERE `id` = Array
ERROR - 2018-09-11 14:18:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\bangalore_shop\system\core\Exceptions.php:271) C:\xampp\htdocs\bangalore_shop\system\core\Common.php 570
ERROR - 2018-09-11 14:19:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\bangalore_shop\application\controllers\admin\product\Productadd.php 144
ERROR - 2018-09-11 14:19:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\bangalore_shop\application\controllers\admin\product\Productadd.php 152
ERROR - 2018-09-11 14:19:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\bangalore_shop\application\controllers\admin\product\Productadd.php 152
ERROR - 2018-09-11 14:19:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\bangalore_shop\application\controllers\admin\product\Productadd.php 153
ERROR - 2018-09-11 14:19:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\bangalore_shop\system\database\DB_query_builder.php 2442
ERROR - 2018-09-11 14:19:59 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: UPDATE `products` SET `prod_image` = 'Array/tulips1.jpg', `prod_name` = 'cgdfgaaaa', `cat_id` = '1', `prod_brand` = 'fghdfg', `prod_url` = 'fdg', `company` = 'dfgdfg', `description` = 'dfgdfg', `specification` = 'fdgdfgdf', `modified_at` = '2018-09-11 14:19:59', `status` = '1'
WHERE `id` = Array
ERROR - 2018-09-11 14:20:17 --> 404 Page Not Found: Upload/acer_predator_notebook_gaming_utility_backpack1.jpg
ERROR - 2018-09-11 14:20:17 --> 404 Page Not Found: Upload/chrysanthemum.jpg
ERROR - 2018-09-11 14:20:21 --> 404 Page Not Found: Assets/css
ERROR - 2018-09-11 14:21:19 --> 404 Page Not Found: Upload/chrysanthemum.jpg
ERROR - 2018-09-11 14:21:19 --> 404 Page Not Found: Upload/acer_predator_notebook_gaming_utility_backpack1.jpg
ERROR - 2018-09-11 14:21:21 --> 404 Page Not Found: Upload/chrysanthemum.jpg
ERROR - 2018-09-11 14:21:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\bangalore_shop\application\controllers\admin\product\Productadd.php 144
ERROR - 2018-09-11 14:21:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\bangalore_shop\application\controllers\admin\product\Productadd.php 152
ERROR - 2018-09-11 14:21:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\bangalore_shop\application\controllers\admin\product\Productadd.php 152
ERROR - 2018-09-11 14:21:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\bangalore_shop\application\controllers\admin\product\Productadd.php 153
ERROR - 2018-09-11 14:21:27 --> 404 Page Not Found: Upload/acer_predator_notebook_gaming_utility_backpack1.jpg
ERROR - 2018-09-11 14:21:33 --> 404 Page Not Found: Upload/acer_predator_notebook_gaming_utility_backpack1.jpg
ERROR - 2018-09-11 14:21:44 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\bangalore_shop\application\controllers\admin\product\Productadd.php 144
ERROR - 2018-09-11 14:21:44 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\bangalore_shop\application\controllers\admin\product\Productadd.php 152
ERROR - 2018-09-11 14:21:44 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\bangalore_shop\application\controllers\admin\product\Productadd.php 152
ERROR - 2018-09-11 14:21:44 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\bangalore_shop\application\controllers\admin\product\Productadd.php 153
ERROR - 2018-09-11 14:21:53 --> 404 Page Not Found: admin/product/Productadd/Delete_product
ERROR - 2018-09-11 14:23:42 --> Severity: Notice --> Undefined property: Productadd::$Minipart_model C:\xampp\htdocs\bangalore_shop\application\controllers\admin\product\Productadd.php 168
ERROR - 2018-09-11 14:23:42 --> Severity: error --> Exception: Call to a member function delete_product() on null C:\xampp\htdocs\bangalore_shop\application\controllers\admin\product\Productadd.php 168
ERROR - 2018-09-11 14:24:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\bangalore_shop\application\controllers\admin\product\Productadd.php 59
ERROR - 2018-09-11 14:24:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\bangalore_shop\application\controllers\admin\product\Productadd.php 67
ERROR - 2018-09-11 14:24:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\bangalore_shop\application\controllers\admin\product\Productadd.php 67
ERROR - 2018-09-11 14:24:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\bangalore_shop\application\models\Product_model.php 9
